import React from 'react'

const About = () => {
  return (
    <>
      <h1>About Learning</h1>
    </>
  )
}

export default About