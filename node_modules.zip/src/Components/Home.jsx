import React from 'react'
import { Link } from 'react-router-dom'
import { useEffect } from 'react'

const Home = () => {
  useEffect(()=>{
    document.title='LMS | HomePage'
  })
  return (
    <div className='container mt-4'>
      {/* Start Latest Courses*/}
      <h3 className=' pb-1 mb-4 mt-5'>Latest Courses<Link to='/all-courses' className='float-end'>See All</Link></h3>
    <div className='row mb-4'>
      <div className='col-md-3'>
        <div className="card">
          <Link to="/detail/1"><img src="logo512.png" className="card-img-top" alt="..." /></Link>
          <div className="card-body">
            <h5 className="card-title"><Link to="/detail/1">Course title</Link></h5>
          </div>
          <div className='card-footer'>
            <div className='title'>
              <span >Rating : 4/5</span>
              <span className='float-end'>Views : 1M</span>
              </div>
          </div>
        </div>
      </div>
      <div className='col-md-3'>
        <div className="card">
          <a href="#"><img src="logo512.png" className="card-img-top" alt="..." /></a>
          <div className="card-body">
            <h5 className="card-title"><a href="#">Course title</a></h5>
          </div>
          <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 3/5</span>
              <span className='float-end'>Views : 100k</span>
              </div>
          </div>
        </div>
      </div>
      <div className='col-md-3'>
        <div className="card">
          <a href="#"><img src="logo512.png" className="card-img-top" alt="..." /></a>
          <div className="card-body">
            <h5 className="card-title"><a href="#">Course title</a></h5>
          </div>
          <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 2.5/5</span>
              <span className='float-end'>Views : 104k</span>
              </div>
          </div>
        </div>
      </div>
      <div className='col-md-3'>
        <div className="card">
          <a href="#"><img src="logo512.png" className="card-img-top" alt="..." /></a>
          <div className="card-body">
            <h5 className="card-title"><a href="#">Course title</a></h5>
          </div>
          <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 2.5/5</span>
              <span className='float-end'>Views : 104k</span>
              </div>
          </div>
        </div>
      </div>
    </div>
      {/* ENd Latest Courses*/}

      {/* popular Courses*/}
      <h3 className=' pb-1 mb-4 mt-5'>Popular Courses<Link to='/popular-courses' className='float-end'>See All</Link></h3>
      <div className='row'>
        <div className='col-md-3'>
          <div className="card">
            <a href="#"><img src="logo512.png" className="card-img-top" alt="..."/></a>
              <div className="card-body">
                <h5 className="card-title"><a href="#">Course title</a></h5>
              </div>
              <div className='card-footer'>
            <div className='title'>
              <span >Rating : 4.5/5 </span>
              <span className='float-end'>Views : 5M</span>
              </div>
          </div>
          </div>
        </div>
        <div className='col-md-3'>
          <div className="card">
            <a href="#"><img src="logo512.png" className="card-img-top" alt="..."/></a>
              <div className="card-body">
                <h5 className="card-title"><a href="#">Course title</a></h5>
              </div>
              <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 4.5/5</span>
              <span className='float-end'>Views : 9.5M</span>
              </div>
          </div>
          </div>
        </div>
        <div className='col-md-3'>
          <div className="card">
            <a href="#"><img src="logo512.png" className="card-img-top" alt="..."/></a>
              <div className="card-body">
                <h5 className="card-title"><a href="#">Course title</a></h5>
              </div>
              <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 4/5</span>
              <span className='float-end'>Views : 11M</span>
              </div>
          </div>
          </div>
        </div>
        <div className='col-md-3'>
          <div className="card">
            <a href="#"><img src="logo512.png" className="card-img-top" alt="..."/></a>
              <div className="card-body">
                <h5 className="card-title"><a href="#">Course title</a></h5>
              </div>
              <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 4/5</span>
              <span className='float-end'>Views : 11M</span>
              </div>
          </div>
          </div>
        </div>
      </div>
      
      {/* ENd Popular Courses*/}

      {/* Popular Teacher Courses*/}
      <h3 className=' pb-1 mb-4 mt-5'>Popular Teachers<Link to='/popular-teachers' className='float-end'>See All</Link></h3>
      <div className='row'>
        <div className='col-md-3'>
          <div className="card">
            <a href="#"><img src="logo512.png" className="card-img-top" alt="..."/></a>
              <div className="card-body">
                <h5 className="card-title"><a href="#">Teacher Name</a></h5>
              </div>
              <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 4/5</span>
              </div>
          </div>
          </div>
        </div>
        
        <div className='col-md-3'>
          <div className="card">
            <a href="#"><img src="logo512.png" className="card-img-top" alt="..."/></a>
              <div className="card-body">
                <h5 className="card-title"><a href="#">Teacher Name</a></h5>
              </div>
              <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 4/5</span>
              </div>
          </div>
          </div>
        </div>
        <div className='col-md-3'>
          <div className="card">
            <a href="#"><img src="logo512.png" className="card-img-top" alt="..."/></a>
              <div className="card-body">
                <h5 className="card-title"><a href="#">Teacher Name</a></h5>
              </div>
              <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 4/5</span>
              </div>
          </div>
          </div>
        </div>
        <div className='col-md-3'>
          <div className="card">
            <a href="#"><img src="logo512.png" className="card-img-top" alt="..."/></a>
              <div className="card-body">
                <h5 className="card-title"><a href="#">Teacher Name</a></h5>
              </div>
              <div className='card-footer'>
            <div className='title'>
              <span className='float'>Rating : 4/5</span>
              </div>
          </div>
          </div>
        </div>
      </div>
      {/* ENd Popular Teacher Courses*/}

      {/* Student Testimonial */}
      <h3 className=' pb-1 mb-4 mt-5'>Student Testimonial</h3>
      <div id="carouselExample" class="carousel slide bg-dark text-white py-5">
        <div className="carousel-inner">
          <div className="carousel-item active">
                <figure class="text-center">
                  <blockquote class="blockquote">
                    <p>A well-known quote, contained in a blockquote element.</p>
                  </blockquote>
                  <figcaption class="blockquote-footer">
                    Someone famous in <cite title="Source Title">Source Title</cite>
                  </figcaption>
                </figure>
          </div>
          <div className="carousel-item">
               <figure class="text-center">
                  <blockquote class="blockquote">
                    <p>A well-known quote, contained in a blockquote element.</p>
                  </blockquote>
                  <figcaption class="blockquote-footer">
                    Someone famous in <cite title="Source Title">Source Title</cite>
                  </figcaption>
                </figure>
          </div>
          <div className="carousel-item">
                <figure class="text-center">
                  <blockquote class="blockquote">
                    <p>A well-known quote, contained in a blockquote element.</p>
                  </blockquote>
                  <figcaption class="blockquote-footer">
                    Someone famous in <cite title="Source Title">Source Title</cite>
                  </figcaption>
                </figure>
          </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
      {/* ENd Student Testimonial*/}
    </div>
  )
}

export default Home
