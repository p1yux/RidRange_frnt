import React from 'react'
import TeacherSidebar from './TeacherSidebar'
import { useEffect } from 'react'

const AddCourses = () => {
    useEffect(()=>{
        document.title='LMS | Add Course'
      })
  return (
    <div className='container mt-4'>
    <div className='row'>
        <aside className='col-md-3'>
            <TeacherSidebar />
        </aside>
        <div className='col-9'>
            <div className='card'>
                <h3 className='card-header'>Add Course</h3>
                <div className='card-body'>
                <form>
                    <div className="mb-3">
                        <label for="exampleInputPassword1" className="form-label">Title</label>
                        <input type="text" className="form-control"/>
                    </div>
                    <div className="mb-3">
                        <label for="exampleInputPassword1" className="form-label">Description</label>
                        <textarea className='form-control'></textarea>
                    </div>
                    <div className="mb-3">
                        <label for="exampleInputPassword1" className="form-label">Upload Course Video</label>
                        <input type="file" className="form-control" id="inputGroupFile02" />
                    </div>
                    <div className="mb-3">
                        <label for="exampleInputPassword1" className="form-label">Technologies</label>
                        <textarea className='form-control'></textarea>
                    </div>
                    <button type="submit" className="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

  </div>
  )
}

export default AddCourses
