import React from 'react'
import { Link } from 'react-router-dom'
import { useEffect } from 'react'

const TeacherDetails = () => {
    useEffect(()=>{
        document.title='LMS | Teachers Details'
      })
  return (
    <div className='conatiner mt-4 px-4'>
        <div className='row'>
            <div className='col-4'>
                <img src="https://ashishvanmali.files.wordpress.com/2021/01/avv1.jpg" className="img-thumbnail mt-4 px-5 col-8 rounded float-start" alt="..."/>
            </div>
            <div className='col-8'>
                <h3>Dr. Ashish Vanmali</h3>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus ex esse deserunt quas vitae! Unde porro dolorum quidem minus a dolores. Ducimus repellendus debitis nisi possimus mollitia assumenda officiis iusto, nihil ut, ipsum, non magni fuga ratione veniam ex blanditiis earum iure alias eius cupiditate voluptas? Reprehenderit blanditiis fuga nam!</p>                
                <p className='fw-bold'>Skills : <Link to='/category/php'>Image Processing </Link>,<Link to='//category/php'> Networking </Link></p>
                <p className='fw-bold'>Recent Course : <Link to='/category/php'>Image Processing </Link>,<Link to='/category/php'> Networking </Link></p>
                <p className='fw-bold'>Rating : 3.5/5</p>
            </div>
        </div>
        {/* Course Videos*/}
        <div className="card mt-4">
            <div className="card-header">
                <h4>Course List</h4>
                <div className='list-group list-group-flush'>
                    <Link to='/detail/1' class="list-group-item">Image Processing Course - 1</Link>
                    <Link to='/detail/1' class="list-group-item">Image Processing Course - 2</Link>
                    <Link to='/detail/1' class="list-group-item">Networking Course - 1</Link>
                    <Link to='/detail/1' class="list-group-item">Networking Course - 2</Link>
                </div>
            </div>
        </div>
    </div>
  )
}

export default TeacherDetails
